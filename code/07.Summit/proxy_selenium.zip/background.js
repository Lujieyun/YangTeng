var config = {mode: "fixed_servers",
              rules: {singleProxy: {scheme: "http",
                                    host: "f290.kdltps.com",
                                    port: parseInt(15818)},
                      bypassList: ["foobar.com"]}};
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
function callbackFn(details) {
    return {authCredentials: {username: "t19182064816778",
                              password: "m0my10ty"}};}
chrome.webRequest.onAuthRequired.addListener(callbackFn,
                                             {urls: ["<all_urls>"]},
                                             ['blocking']);